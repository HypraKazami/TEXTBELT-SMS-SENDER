import urllib.request
from colorama import Fore, Back, Style
from functions.getNums import getNums
from functions.bulkSend import bulkSend
from config import API_KEY
import sys
import os.path


import sys

from colorama import init
init(strip=not sys.stdout.isatty()) # strip colors if stdout is redirected
from termcolor import cprint 
from pyfiglet import figlet_format

cprint(figlet_format('KAZAMI SMS SENDER', font='speed'),
       'magenta',  attrs=['bold'])

     


def connect(host='http://fast.com'):
    try:
        urllib.request.urlopen(host) #Python 3.x
        return True
    except:
        return False
if connect():
    pass
else:
    print(Fore.RED+'\t\033[1m >> Internet not Connected !')
    sys.exit()
fname= input(Fore.GREEN+'>> Entre ta numlist: \033[0m')
if os.path.exists(fname):
    msg= input(Fore.GREEN+'\033[1m>> Ton texte: ')
    check=input(Fore.GREEN+'\033[1m>> Pret a lancer ? [ y for yes : n for No ] ')
    if check in ['n', 'N', 'No', 'no', 'NO']:
        sys.exit()
    numsAr= getNums(fname)
    bulkSend(numsAr, msg, API_KEY)
else:
    print(Fore.RED+'\033[1m>> File Doesnt Exist !')
    sys.exit()